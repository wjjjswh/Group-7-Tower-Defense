using UnityEngine;


public class Tower : MonoBehaviour
{
    public float range = 5f;
    public float fireRate = 1f;
    public GameObject projectilePrefab;


    float fireCountdown;


    void Update()
    {
        fireCountdown -= Time.deltaTime;
        if (fireCountdown <= 0f)
        {
            Enemy target = FindTarget();
            if (target != null)
            {
                Shoot(target);
                fireCountdown = 1f / (fireRate * GameManager.Instance.fireRateMultiplier);
            }
        }
    }


    Enemy FindTarget()
    {
        Enemy[] enemies = Object.FindObjectsByType<Enemy>(FindObjectsSortMode.None);
        Enemy closest = null;
        float minDist = Mathf.Infinity;


        foreach (Enemy e in enemies)
        {
            float d = Vector2.Distance(transform.position, e.transform.position);
            if (d < range && d < minDist)
            {
                minDist = d;
                closest = e;
            }
        }
        return closest;
    }


    void Shoot(Enemy target)
    {
        GameObject proj = Instantiate(projectilePrefab, transform.position, Quaternion.identity);
        proj.GetComponent<Projectile>().SetTarget(target);
    }
}