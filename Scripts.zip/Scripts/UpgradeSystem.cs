using UnityEngine;


public class UpgradeSystem : MonoBehaviour
{
    public void ApplyRandomUpgrade()
    {
        int roll = Random.Range(0, 3);


        switch (roll)
        {
            case 0:
                GameManager.Instance.damageMultiplier += 0.25f;
                break;
            case 1:
                GameManager.Instance.fireRateMultiplier += 0.2f;
                break;
            case 2:
                GameManager.Instance.goldMultiplier += 0.3f;
                break;
        }
    }
}