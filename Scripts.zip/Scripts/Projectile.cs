using UnityEngine;


public class Projectile : MonoBehaviour
{
    public float speed = 10f;
    public int baseDamage = 5;


    Enemy target;


    public void SetTarget(Enemy t)
    {
        target = t;
    }


    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }


        transform.position = Vector2.MoveTowards(
        transform.position,
        target.transform.position,
        speed * Time.deltaTime
        );


        if (Vector2.Distance(transform.position, target.transform.position) < 0.1f)
        {
            int dmg = Mathf.RoundToInt(baseDamage * GameManager.Instance.damageMultiplier);
            target.TakeDamage(dmg);
            Destroy(gameObject);
        }
    }
}