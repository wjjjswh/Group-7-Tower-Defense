using UnityEngine;


public class Enemy : MonoBehaviour
{
    public float speed = 2f;
    public int maxHealth = 10;
    private int currentHealth;


    void Start()
    {
        currentHealth = maxHealth + GameManager.Instance.wave * 2;
    }


    void Update()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }


    public void TakeDamage(int dmg)
    {
        currentHealth -= dmg;
        if (currentHealth <= 0)
        {
            Die();
        }
    }


    void Die()
    {
        GameManager.Instance.gold += Mathf.RoundToInt(10 * GameManager.Instance.goldMultiplier);
        Destroy(gameObject);
    }
}