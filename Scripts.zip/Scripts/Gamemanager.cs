using UnityEngine;


public class GameManager : MonoBehaviour
{
    public static GameManager Instance;


    public int gold = 100;
    public int wave = 1;


    // Roguelike modifiers
    public float damageMultiplier = 1f;
    public float fireRateMultiplier = 1f;
    public float goldMultiplier = 1f;


    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }


    public void NextWave()
    {
        wave++;
        Object.FindFirstObjectByType<EnemySpawner>().StartWave();
    }
}